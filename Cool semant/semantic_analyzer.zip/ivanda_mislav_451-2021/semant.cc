#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include "semant.h"
#include "utilities.h"


extern int semant_debug;
extern char *curr_filename;

//////////////////////////////////////////////////////////////////////
//
// Symbols
//
// For convenience, a large number of symbols are predefined here.
// These symbols include the primitive type and method names, as well
// as fixed names used by the runtime system.
//
//////////////////////////////////////////////////////////////////////
static Symbol 
    arg,
    arg2,
    Bool,
    concat,
    cool_abort,
    copy,
    Int,
    in_int,
    in_string,
    IO,
    length,
    Main,
    main_meth,
    No_class,
    No_type,
    Object,
    out_int,
    out_string,
    prim_slot,
    self,
    SELF_TYPE,
    Str,
    str_field,
    substr,
    type_name,
    val;
//
// Initializing the predefined symbols.
//
static void initialize_constants(void)
{
    arg         = idtable.add_string("arg");
    arg2        = idtable.add_string("arg2");
    Bool        = idtable.add_string("Bool");
    concat      = idtable.add_string("concat");
    cool_abort  = idtable.add_string("abort");
    copy        = idtable.add_string("copy");
    Int         = idtable.add_string("Int");
    in_int      = idtable.add_string("in_int");
    in_string   = idtable.add_string("in_string");
    IO          = idtable.add_string("IO");
    length      = idtable.add_string("length");
    Main        = idtable.add_string("Main");
    main_meth   = idtable.add_string("main");
    //   _no_class is a symbol that can't be the name of any 
    //   user-defined class.
    No_class    = idtable.add_string("_no_class");
    No_type     = idtable.add_string("_no_type");
    Object      = idtable.add_string("Object");
    out_int     = idtable.add_string("out_int");
    out_string  = idtable.add_string("out_string");
    prim_slot   = idtable.add_string("_prim_slot");
    self        = idtable.add_string("self");
    SELF_TYPE   = idtable.add_string("SELF_TYPE");
    Str         = idtable.add_string("String");
    str_field   = idtable.add_string("_str_field");
    substr      = idtable.add_string("substr");
    type_name   = idtable.add_string("type_name");
    val         = idtable.add_string("_val");
}
                                       
ClassTable::ClassTable(Classes classes) : semant_errors(0) , error_stream(cerr) {
    // KONSTRUKTOR OD ClassTable
    // Prima niz klasa Phylum tipa class -> program je zapravo lista klasa pa stoga prima sve klase programa
    //Napravi graf klasa i provjeri uvjete definirane za nasljeđivanje i definiranje klasa
    //u classesTable property sacuvaj listu svih klasa od programa -> OKOLINA KLASA KOJA CE SLIJEDIT symtab format
    //symtab.h definira listu koja će sadržavat članove pri čemu svaki član odgovara jednom scope-u
    //kod okoline klasa imamo jedan jedinstveni scope(globalni, nema nested klasa) pa stavljamo sve klase u taj jedan scope(1 clan liste)
    //alocira prvi i jedini clan symtab liste
    this->classesTable.enterscope();
    //Lista za predstavljanje stabla nasljeđivanja klasa modelom grafa za provjeru ciklicnosti -> svakoj klasi pridruzuje broj čvora
    this->classNameToNumberMapping.enterscope();
    //Klase programa + 5 osnovnih klasa, indeskiranje čvorova grafa
    int vertexNumbers[classes->len()+5];
    for(int i=0;i<(classes->len()+5);i++)
    {
        vertexNumbers[i]=i;
    }
    Graph classesGraph(classes->len()+5);
    //dodaj osnovne klase u tablicu klasa zajedno  njihovim okolinama identifikatora i metoda
    install_basic_classes(classesGraph, vertexNumbers);
    //u classesGraph definiraj graf nasljeđivanja i provjeri ima li ciklicnosti
    //BROJ CVOROVA = BROJ KLASA
    //KLASE CEMO OZNACAVAT BROJEVIMA PO NJIHOVOM REDOSLIJEDU UNUTAR classes LISTE
    class__class* currentClass;
    Symbol currentClassName;
    Symbol currentParentName;
    for (int classIndex = classes->first(); classes->more(classIndex); classIndex = classes->next(classIndex))
    {
        //polimorfizam s castanjem u pokazivač child klase
        currentClass = (class__class*)classes->nth(classIndex);
        currentClassName = currentClass->getClassName();
        currentParentName = currentClass->getParentName();
        //DODAJ KLASU U MAPU BITNU ZA GRAF KLASA
        this->classNameToNumberMapping.addid(currentClassName, &vertexNumbers[classIndex+5]);
        //Nije dozvoljeno definiranje iste klase vise puta -> provjeri je li treutna klasa vec definirana
        if(this->classesTable.probe(currentClassName))
        {
            //vec postoji -> error -> dupla deklaracija
            //prekini semanticku analizu
            //metode za error vracaju streamove
            this->semant_error(currentClass) << "Multiple definitions for class " << currentClassName << endl;
            //ovo ce uvecat semant_errors koji se provjerava nakon poziva funkcije u glavnoj metodi
            return;
        }
        //SELF_TYPE SE NE SMI NALAZIT KAO INHERIT KLASA NITI KAO IME KLASE
        //It is an error to inherit from or redefine Int
        //It is an error to inherit from or redefine String
        //It is an error to inherit from or redefine Bool.
        //It is an error to redefine the IO class.
        if(currentClassName == Int || currentClassName == Object || currentClassName == Bool || currentClassName == IO || currentClassName == Str || currentClassName == SELF_TYPE)
        {
            this->semant_error(currentClass) << "Cannot redefine class " << currentClassName << endl;
            return;
        }
        if(currentParentName == SELF_TYPE || currentParentName == Int || currentParentName == Str || currentParentName == Bool)
        {
            this->semant_error(currentClass) << "Cannot inherit from " << currentParentName << endl;
            return;
        }
        //ako nema nijednog errora dodaj u classTable
        this->classesTable.addid(currentClassName,currentClass);
    }
    //NAKON OVOG IMAMO DODANE SVE KLASE
    for (int classIndex = classes->first(); classes->more(classIndex); classIndex = classes->next(classIndex))
    {
        currentClass = (class__class*)classes->nth(classIndex);
        currentClassName = currentClass->getClassName();
        currentParentName = currentClass->getParentName();
        //napuni methodTable i identifictorsTable okoline po feature_type atributu i FeatureType enumu koji definira koji dio ćemo punit
        Features classFeatures = currentClass->getClassFeatures();
        Feature currentClassFeature;
        attr_class* currentClassAttribute;
        method_class* currentClassMethod;
        //otvori identificatorsTable i methodsTable dosege
        currentClass->identificatorsTable.enterscope();
        currentClass->methodsTable.enterscope();
        for (int featureIndex = classFeatures->first(); classFeatures->more(featureIndex); featureIndex = classFeatures->next(featureIndex))
        {
            //enum featureType dostupan kroz semant.h di se importa cool-tree.h
            currentClassFeature = classFeatures->nth(featureIndex);
            if(currentClassFeature->feature_type == attributeType)
            {
                //castaj u pokazivac attribute klase kako bi mogli pristupit propertyima od atributa -> polimorfizam
                currentClassAttribute = (attr_class*)currentClassFeature;
                //provjeri je li atribut vec prethodno bio definiran unutar trenutne klase(PARENTE GLEDAMO U DRUGOM PROLAZU) -> nema duplih deklaracija
                //DOVOLJAN .probe jer imamo samo 1 glavni doseg
                if(currentClass->identificatorsTable.probe(currentClassAttribute->getAttributeName()))
                {
                    this->semant_error(currentClass) << "Cannot redefine attribute " << currentClassAttribute->getAttributeName() << endl;
                    return;
                }
                //PRETHODNO NAPUNILI SVE MOGUCE KLASE, KLASA = TIP -> PROVJERI JE LI SE TIP VARIJABLE NALAZI U OKRUZENJU SVIH KLASA
                if(!this->classesTable.probe(currentClassAttribute->getTypeDeclaration()))
                {
                    this->semant_error(currentClass) << "Attribute " << currentClassAttribute->getAttributeName() << " has undefined type " <<currentClassAttribute->getTypeDeclaration() << endl;
                    return;
                }
                //It is also illegal to have attributes named self
                if(currentClassAttribute->getAttributeName() == self)
                {
                    this->semant_error(currentClass) << "Cannot have attribute with name self" << endl;
                    return;
                }
                //DODAJ AKO NEMA NIJEDNOG OD PRETHODNIH ERRORA
                currentClass->identificatorsTable.addid(currentClassAttribute->getAttributeName(),currentClassAttribute);
                //SPREMI TIP OD SPREMLJENOG tree_node U TABLICI SIMBOLA KIJEM CEMO PRISTUPAT KOD DOHVATA
                currentClassAttribute->identificatorTypeDeclaration = currentClassAttribute->getTypeDeclaration();
            }
            else if(currentClassFeature->feature_type == methodType)
            {
                //castaj u pokazivac metode klase kako bi mogli pristupit propertyima od metode -> polimorfizam
                currentClassMethod = (method_class*)currentClassFeature;
                //provjeri je li metoda vec prethodno definirana -> nema duplih deklaracija
                if(currentClass->methodsTable.probe(currentClassMethod->getMethodName()))
                {
                    this->semant_error(currentClass) << "Cannot redefine method " << currentClassMethod->getMethodName() << endl;
                    return;
                }
                //NE SMI IMAT UNDEFINED RETURN TYPE
                if(currentClass->methodsTable.probe(currentClassMethod->getMethodReturnType()))
                {
                    this->semant_error(currentClass) << "Method " << currentClassMethod->getMethodName() << " has undefined return type" << endl;
                    return;                   
                }
                currentClass->methodsTable.addid(currentClassMethod->getMethodName(),(tree_node*)currentClassMethod);
            }
        }
    }
    //KONSTRUIRAJ GRAF SA PRIKUPLJENIM VRIJEDNOSTIMA
    for(int classIndex = classes->first(); classes->more(classIndex); classIndex = classes->next(classIndex))
    {
        currentClass = (class__class*)classes->nth(classIndex);
        currentClassName = currentClass->getClassName();
        currentParentName = currentClass->getParentName();
        //PROVJERI JE LI POSTOJI PARENT KLASA OD KOJE SE INHERITA
        if(this->classesTable.probe(currentParentName))
        {
            classesGraph.addEdge(*(this->classNameToNumberMapping.probe(currentClassName)),*(this->classNameToNumberMapping.probe(currentParentName)));
        }
        else {
            this->semant_error(currentClass) << "Cannot inherit from an undefined class " << currentParentName << endl;
            return;   
        }
    }
    //PROVJERI CIKLICNOST
    if(classesGraph.isCyclic())
    {
        this->semant_error() << "Cylic class inheritance" << endl;
        return;
    }
    //Potrebno je da bude prisutna klasa main i to samo jedna + klasa Main mora imati metodu main()
    class__class* mainClass = (class__class*)this->classesTable.probe(Main);
    if(!mainClass)
    {
        this->semant_error() << "Program must contain 'Main' class" << endl;
        return;
    }
    else if(!mainClass->methodsTable.probe(main_meth))
    {
        this->semant_error() << "'Main' class must contain 'main()' method" << endl;
        return;
    }
}

void ClassTable::install_basic_classes(Graph classesGraph, int* vertexNumbers) {

    // The tree package uses these globals to annotate the classes built below.
   // curr_lineno  = 0;
    Symbol filename = stringtable.add_string("<basic class>");
    
    // The following demonstrates how to create dummy parse trees to
    // refer to basic Cool classes.  There's no need for method
    // bodies -- these are already built into the runtime system.
    
    // IMPORTANT: The results of the following expressions are
    // stored in local variables.  You will want to do something
    // with those variables at the end of this method to make this
    // code meaningful.

    // 
    // The Object class has no parent class. Its methods are
    //        abort() : Object    aborts the program
    //        type_name() : Str   returns a string representation of class name
    //        copy() : SELF_TYPE  returns a copy of the object
    //
    // There is no need for method bodies in the basic classes---these
    // are already built in to the runtime system.

    Class_ Object_class =
	class_(Object, 
	       No_class,
	       append_Features(
			       append_Features(
					       single_Features(method(cool_abort, nil_Formals(), Object, no_expr())),
					       single_Features(method(type_name, nil_Formals(), Str, no_expr()))),
			       single_Features(method(copy, nil_Formals(), SELF_TYPE, no_expr()))),
	       filename);

    // 
    // The IO class inherits from Object. Its methods are
    //        out_string(Str) : SELF_TYPE       writes a string to the output
    //        out_int(Int) : SELF_TYPE            "    an int    "  "     "
    //        in_string() : Str                 reads a string from the input
    //        in_int() : Int                      "   an int     "  "     "
    //
    Class_ IO_class = 
	class_(IO, 
	       Object,
	       append_Features(
			       append_Features(
					       append_Features(
							       single_Features(method(out_string, single_Formals(formal(arg, Str)),
										      SELF_TYPE, no_expr())),
							       single_Features(method(out_int, single_Formals(formal(arg, Int)),
										      SELF_TYPE, no_expr()))),
					       single_Features(method(in_string, nil_Formals(), Str, no_expr()))),
			       single_Features(method(in_int, nil_Formals(), Int, no_expr()))),
	       filename);  

    //
    // The Int class has no methods and only a single attribute, the
    // "val" for the integer. 
    //
    Class_ Int_class =
	class_(Int, 
	       Object,
	       single_Features(attr(val, prim_slot, no_expr())),
	       filename);

    //
    // Bool also has only the "val" slot.
    //
    Class_ Bool_class =
	class_(Bool, Object, single_Features(attr(val, prim_slot, no_expr())),filename);

    //
    // The class Str has a number of slots and operations:
    //       val                                  the length of the string
    //       str_field                            the string itself
    //       length() : Int                       returns length of the string
    //       concat(arg: Str) : Str               performs string concatenation
    //       substr(arg: Int, arg2: Int): Str     substring selection
    //       
    Class_ Str_class =
	class_(Str, 
	       Object,
	       append_Features(
			       append_Features(
					       append_Features(
							       append_Features(
									       single_Features(attr(val, Int, no_expr())),
									       single_Features(attr(str_field, prim_slot, no_expr()))),
							       single_Features(method(length, nil_Formals(), Int, no_expr()))),
					       single_Features(method(concat, 
								      single_Formals(formal(arg, Str)),
								      Str, 
								      no_expr()))),
			       single_Features(method(substr, 
						      append_Formals(single_Formals(formal(arg, Int)), 
								     single_Formals(formal(arg2, Int))),
						      Str, 
						      no_expr()))),
	       filename);
    //You will want to do something
    // with those variables at the end of this method to make this
    // code meaningful.
    //POTREBNO DODAT OSNOVNE KLASE U PRIMLJENU TABLICU KLASA JER TAMO NE POSTOJE -> DODAJU SE SAMO KLASE IZ PROGRAMA
    //MORAMO I ZA NJIH NPR GLEDAT JE LI DOSLO DO REDEFIIRANJA ODNOSNO JE LI KORISNIK NEKU OD KLASA NAZVAO ISTO KAO STA JE OSNOVNA
    //OVO SE ODVIJA PRIJE PROLASKA KROZ KLASE PROGRAMA
    //Osim toga, u jeziku Cool nasljeđivanje od osnovnih klasa ima svojih ograničenja -> COOL MANUAL
    //DRUGI CLAN JE class_ TIPA -> castaj u pokazivac
    //DODAJ NJIHOVE DEFAULTNE METODE U TABLICU METODA I OTVORI TABLICU IDENTIFIKATORA IAKO IH NEMA(da prilikom probe i lookup ne bude greska umjesto NULL)
    ((class__class*)Object_class)->methodsTable.enterscope();
    ((class__class*)Object_class)->methodsTable.addid(cool_abort,(tree_node*)method(cool_abort, nil_Formals(), Object, no_expr()));
    ((class__class*)Object_class)->methodsTable.addid(type_name,(tree_node*)method(type_name, nil_Formals(), Str, no_expr()));
    ((class__class*)Object_class)->methodsTable.addid(copy,(tree_node*)method(copy, nil_Formals(), SELF_TYPE, no_expr()));
    ((class__class*)Object_class)->identificatorsTable.enterscope();

    ((class__class*)IO_class)->methodsTable.enterscope();
    ((class__class*)IO_class)->methodsTable.addid(out_string, (tree_node*)method(out_string, single_Formals(formal(arg, Str)),SELF_TYPE, no_expr()));
    ((class__class*)IO_class)->methodsTable.addid(out_int, (tree_node*)method(out_int, single_Formals(formal(arg, Int)),SELF_TYPE, no_expr()));
    ((class__class*)IO_class)->methodsTable.addid(in_string, (tree_node*)method(in_string, nil_Formals(), Str, no_expr()));
    ((class__class*)IO_class)->methodsTable.addid(in_int, (tree_node*)method(in_int, nil_Formals(), Int, no_expr()));
    ((class__class*)IO_class)->identificatorsTable.enterscope();
    
    ((class__class*)Int_class)->methodsTable.enterscope();
    ((class__class*)Int_class)->identificatorsTable.enterscope();

    ((class__class*)Bool_class)->methodsTable.enterscope();
    ((class__class*)Bool_class)->identificatorsTable.enterscope();

    ((class__class*)Str_class)->methodsTable.enterscope();
    ((class__class*)Str_class)->methodsTable.addid(length, (tree_node*)method(length, nil_Formals(), Int, no_expr()));
    ((class__class*)Str_class)->methodsTable.addid(concat,(tree_node*)method(concat, single_Formals(formal(arg, Str)),Str,no_expr()));
    ((class__class*)Str_class)->methodsTable.addid(substr,(tree_node*)method(substr, append_Formals(single_Formals(formal(arg, Int)), single_Formals(formal(arg2, Int))),Str,no_expr()));
    ((class__class*)Str_class)->identificatorsTable.enterscope();

    this->classesTable.addid(Object,(tree_node*)Object_class);
    this->classNameToNumberMapping.addid(Object,&vertexNumbers[0]);
    this->classesTable.addid(IO,(tree_node*)IO_class);
    this->classNameToNumberMapping.addid(IO,&vertexNumbers[1]);
    this->classesTable.addid(Int,(tree_node*)Int_class);
    this->classNameToNumberMapping.addid(Int,&vertexNumbers[2]);
    this->classesTable.addid(Bool,(tree_node*)Bool_class);
    this->classNameToNumberMapping.addid(Bool,&vertexNumbers[3]);
    this->classesTable.addid(Str,(tree_node*)Str_class);
    this->classNameToNumberMapping.addid(Str,&vertexNumbers[4]);
}

////////////////////////////////////////////////////////////////////
//
// semant_error is an overloaded function for reporting errors
// during semantic analysis.  There are three versions:
//
//    ostream& ClassTable::semant_error()                
//
//    ostream& ClassTable::semant_error(Class_ c)
//       print line number and filename for `c'
//
//    ostream& ClassTable::semant_error(Symbol filename, tree_node *t)  
//       print a line number and filename
//
///////////////////////////////////////////////////////////////////

//FUNKCIJA KOJA SE POZIVA ZA ISPIS GRESAKA PRILIKOM SEMANTICKE ANALIZE
//Ova funkcija prima objekt Class_ i vraća izlazni tok na koji možete ispisivati greške
//SALJEMO JOJ KAO PARAMETAR KLASU UNUTAR KOJE SE DOGODILA GRESKA SEMANTICKE ANALIZE
//ONA NAKNADNIM POZIVAMO UVECA ERROR COUNTER I ODREDI LINIJU
ostream& ClassTable::semant_error(Class_ c)
{                                                             
    return semant_error(c->get_filename(),c);
}    

ostream& ClassTable::semant_error(Symbol filename, tree_node *t)
{
    error_stream << filename << ":" << t->get_line_number() << ": ";
    return semant_error();
}

ostream& ClassTable::semant_error()                  
{                                                 
    semant_errors++;                            
    return error_stream;
} 



/*   This is the entry point to the semantic checker.

     Your checker should do the following two things:

     1) Check that the program is semantically correct
     2) Decorate the abstract syntax tree with type information
        by setting the `type' field in each Expression node.
        (see `tree.h') -> tree.h definira tree_node interface koje implementiraju svi cvorovi AST
        //   The public methods are:
        //   Symbol get_type();      return the type 
        //
        //   tree_node *set(tree_node *t)
        //   sets the line number and type of "this" to the values in
        //   the argument tree_node.  Returns "this".
        //cool-tree.handcode.h -> Expression
        Symbol type;                                 \
        Symbol get_type() { return type; }           \
        Expression set_type(Symbol s) { type = s; return this; }
        


     You are free to first do 1), make sure you catch all semantic
     errors. Part 2) can be done in a second stage, when you want
     to build mycoolc.
 */
//2. PROLAZ AST-A NAKON PUNJENJA OKOLINE KLASA
void program_class::walk_down(ClassTable* classTable)
{
    //ZA SVAKU KLASU SU PRETHODNO NAPUNJENNE OKOLINE METODA I ATRIBUTA(IDENTIFIKATORI U GLAVNOM DOSEGU VIDLJIVOM U CIJELOJ KLASI)
    //REKURZIVNI OBILAZAK STABLA
    //KRENEMO OD SVIH KLASA U PROGRAMU(PROGRAM = LISTA KLASA) I REKURIZVNO IDEMO(KROZ NJIHOVE ATRIBUTE I METODE) SVE DO LISTOVA AST STABLA
    class__class* currentClass;
    for (int classIndex = this->classes->first(); this->classes->more(classIndex); classIndex = this->classes->next(classIndex))
    {
        currentClass = (class__class*)this->classes->nth(classIndex);
        //rekurzivno pozovi walk_down metodu za svaku klasu
        currentClass->walk_down(classTable);
    }
}

void class__class::walk_down(ClassTable* classTable)
{
    //prolazi kroz attribute i metode zadane klase i radi rekurzivni walk_down
    Features classFeatures = this->getClassFeatures();
    Feature currentClassFeature;
    attr_class* currentClassAttribute;
    method_class* currentClassMethod;
    for (int featureIndex = classFeatures->first(); classFeatures->more(featureIndex); featureIndex = classFeatures->next(featureIndex))
    {
        //enum featureType dostupan kroz semant.h di se importa cool-tree.h
        currentClassFeature = classFeatures->nth(featureIndex);
        if(currentClassFeature->feature_type == attributeType)
        {
            currentClassAttribute = (attr_class*)currentClassFeature;
            //Inherited attributes cannot be redefined.
            //AKO POSTOJI TAJ ATRIBUT U NEKOM O PARENTA ONDA JAVI ERROR
            if(classTable->checkAttributeOverride(currentClassAttribute->getAttributeName(), this->getParentName()))
            {
                classTable->semant_error(this) << "Attribute " << currentClassAttribute->getAttributeName() << " is an attribute of an inherited class." << endl;
                return;
            }
            currentClassAttribute->walk_down(classTable, this);
        }
        else if(currentClassFeature->feature_type == methodType)
        {
            currentClassMethod = (method_class*)currentClassFeature;
            //The rule is simple: If a class C inherits a method f from an ancestor class P, then C may override the inherited definition of f provided the number of arguments, the types of the formal parameters, and the return type are exactly the same in both definitions
            //DOPUŠTEN OVERRIDE(ISTO IME METODE) ALI I SVE OSTALO U METODI MORA BIT ISTO
            if(classTable->checkMethodOverride(currentClassFeature, this->getParentName(), (Class_*)this))
            {
                return;
            }
            else currentClassMethod->walk_down(classTable,this);
        }
    }
}

void attr_class::walk_down(ClassTable* classTable, class__class* attributeClass)
{
    Symbol attributeType= this->getTypeDeclaration();
    Expression attributeInitExpression = this->getAttributeInitializationExpression();
    //odradi walk_down za inicijalizacijski expression -> to ce postavit njegov tip
    //ako ne postoji -> no_expr -> bit ce no_type tip
    attributeInitExpression->walk_down(classTable, attributeClass);
    //provjeri je li zadovoljeno da je tip init expressiona <= specificranom tipu atributa ako nije no expression
    if(attributeInitExpression->type != No_type && !classTable->isSubtype(attributeType,attributeInitExpression->type, (Class_*)attributeClass))
    {
        //GRESKA -> ISPISI JE I NASTAVI SMENATICKU ANALIZU
        classTable->semant_error(attributeClass) << "Type of attribute " << this->getAttributeName() << " expression must be subtype of " << attributeType <<endl;
    }
}

void method_class::walk_down(ClassTable* classTable, class__class* methodClass)
{
    //provjeri je li povratni tip metode definiran, dozvoljen je SELF_TYPE a on nije unutar tablice klasa pa i to osiguravamo
    if(this->getMethodReturnType() != SELF_TYPE && !classTable->classesTable.probe(this->getMethodReturnType()))
    {
        //GRESKA -> ISPISI JE I NASTAVI SMENATICKU ANALIZU
        classTable->semant_error(methodClass) << "Undefined return type " << this->getMethodReturnType() << " in method " << this->getMethodName() <<endl;
    }
    else {
        //METODA SADRZI TRENUTNI DOSEG KLASE KOJI SE PROSIRUJE PARAMETRIMA METODE
        //OC is extended with bindings for the formal parameters and self(definira se dinamički kod dispatchanja)
        //DEFINIRAJ NOVI DOSEG KOJI CEMO PUNIT S PARAMETRIMA METODE I INDETIFIKATORIMA U TIJELU METODE(BLOK DEFINIRA VLASTITi DOSEG)
        //IDENTIKATORI MORAJU BIT DEKLARIRANI NA 2 NACINA = ATRIBUT KLASE ILI FORMAL(parametar metode)-> njih punimo u formalsTable za svaku klasu i metodu
        //definiraj novi doseg unutar metode za identifikatore
        methodClass->identificatorsTable.enterscope();
        //DODAJ PARAMETRE PROLAZEĆI KROZ LISTU SVIH formalsa I ODREDI IM TIPOVE
        formal_class* currentMethodFormal;
        Formals methodFormals = this->getMethodFormals();
        for(int formalIndex = methodFormals->first();methodFormals->more(formalIndex); formalIndex = methodFormals->next(formalIndex))
        {
            currentMethodFormal = (formal_class*)methodFormals->nth(formalIndex);
            //parametri(formalsi) ne smiju bit SELF_TYPE tipa
            if(currentMethodFormal->getTypeDeclaration() == SELF_TYPE)
            {
                classTable->semant_error(methodClass) << "Method " << this->getMethodName() << " arguments can't be declared with SELF_TYPE." << endl;
            }
            //it is an error to assign to self or to bind self in a let, a case, ---or as a formal parameter---- -> NE SMI IME PARAMETRA BITI self
            if(currentMethodFormal->getFormalName() == self)
            {
                classTable->semant_error(methodClass) << "Method " << this->getMethodName() << " 'self' can't be an argument of method" << endl;
            }
            //ne smi imat isto ime kao neki drugi formal u OVOM(TRENUTNOM) dosegu -> ne sme bit 2 parametra s istim imenom -> samo probe(MOZE IMAT ISTO IME KAO NEKI ATRIBUT KLASE ILI PARENTA ALI CE GA OVI NADJACAT U TRENUTNOM DOSEGU)
            if(methodClass->identificatorsTable.probe(currentMethodFormal->getFormalName()))
            {
                classTable->semant_error(methodClass) << "Method " << this->getMethodName() << " formal parameter " << currentMethodFormal->getFormalName() << " has already been declared" << endl;
            }
            methodClass->identificatorsTable.addid(currentMethodFormal->getFormalName(),currentMethodFormal);
            //SPREMI TIP OD SPREMLJENOG tree_node U TABLICI SIMBOLA KIJEM CEMO PRISTUPAT KOD DOHVATA
            currentMethodFormal->identificatorTypeDeclaration = currentMethodFormal->getTypeDeclaration();
        }
        //The type of the method body must conform to the declared return type.
        Expression methodBodyExpression = this->getMethodBodyExpression();
        methodBodyExpression->walk_down(classTable,methodClass);
        if(!classTable->isSubtype(this->getMethodReturnType(),methodBodyExpression->type, (Class_*)methodClass))
        {
            //GRESKA -> ISPIS JE I NASTAVI SMENATICKU ANALIZU
            classTable->semant_error(methodClass) << "Method " << this->getMethodName() << " body return type is " << methodBodyExpression->type << " which is different than declared " << this->getMethodReturnType() << " type in definition " <<endl;
        }
        //napunili scope od metode -> nakon obrade expressiona izlazimo iz tog scopea jer nismo vise u metodi -> NEMAMO VISE PRISTUP IDENTIFIKATORIMA U LOKALNOM DOSEGU METODE
        methodClass->identificatorsTable.exitscope();
    }
}

void Expression_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    //ova metoda ce odredit o kojem je tipu expressiona rijec i pozvat njegove walk_down metode -> jedinstvena metoda za svaki expression unutar koje ce se raditI, razlicite vrste walk_down ovisno o tipu expressiona
    if(this->expression_type == assignExpression)
    {
        assign_class* assignExpression = (assign_class*)this;
        assignExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == staticDispatchExpression)
    {
        static_dispatch_class* staticDispatchExpression = (static_dispatch_class*)this;
        staticDispatchExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == dispatchExpression)
    {
        dispatch_class* dispatchExpression = (dispatch_class*)this;
        dispatchExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == conditionalExpression)
    {
        cond_class* conditionalExpression = (cond_class*)this;
        conditionalExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == loopExpression)
    {
        loop_class* loopExpression = (loop_class*)this;
        loopExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == caseExpression)
    {
        typcase_class* caseExpression = (typcase_class*)this;
        caseExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == blockExpression)
    {
        block_class* blockExpression = (block_class*)this;
        blockExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == letExpression)
    {
        let_class* letExpression = (let_class*)this;
        letExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == plusExpression)
    {
        plus_class* plusExpression = (plus_class*)this;
        plusExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == subExpression)
    {
        sub_class* subExpression = (sub_class*)this;
        subExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == mulExpression)
    {
        mul_class* mulExpression = (mul_class*)this;
        mulExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == divideExpression)
    {
        divide_class* divideExpression = (divide_class*)this;
        divideExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == negExpression)
    {
        neg_class* negExpression = (neg_class*)this;
        negExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == ltExpression)
    {
        lt_class* ltExpression = (lt_class*)this;
        ltExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == eqExpression)
    {
        eq_class* eqExpression = (eq_class*)this;
        eqExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == leqExpression)
    {
        leq_class* leqExpression = (leq_class*)this;
        leqExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == compExpression)
    {
        comp_class* compExpression = (comp_class*)this;
        compExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == intConstExpression)
    {
        int_const_class* intConstExpression = (int_const_class*)this;
        intConstExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == boolConstExpression)
    {
        bool_const_class* boolConstExpression = (bool_const_class*)this;
        boolConstExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == stringConstExpression)
    {
        string_const_class* stringConstExpression = (string_const_class*)this;
        stringConstExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == newExpression)
    {
        new__class* newExpression = (new__class*)this;
        newExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == isVoidExpression)
    {
        isvoid_class* isVoidExpression = (isvoid_class*)this;
        isVoidExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == noExpression)
    {
        no_expr_class* noExpression = (no_expr_class*)this;
        noExpression->walk_down(classTable,expressionClass);
    }
    else if(this->expression_type == objectExpression)
    {
        object_class* objectExpression = (object_class*)this;
        objectExpression->walk_down(classTable,expressionClass);
    }
}

void assign_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    //it is an error to assign to self or to bind self in a let, a case, ---or as a formal parameter---- -> ne mozemo assignat vrijednost self-u -> prva provjera
    if(this->getAssignIdentificator() == self)
    {
        classTable->semant_error(expressionClass->getClassFileName(), this) << "Cannot assign to 'self'." << endl;
        this->set_type(No_type);
    }
    else {
        //POTRAZI TIP OD IDENTIFIKATORA U TABLICI SIMBOLA
        tree_node* identificator =  classTable->checkClassIdentifier(this->getAssignIdentificator(), expressionClass->getClassName());
        if(!identificator)
        {
            //GREŠKA
            classTable->semant_error(expressionClass) << "Assign expression identificator " << this->getAssignIdentificator() << " is not defined" << endl;
            this->set_type(No_type);
        }
        else {
            //TIP EXPRESSIONA OD KOJEG SE ASSIGNA VRIJENDOST MORA BIT PODTIP OD SPECIFICRANOG TIPA 
            //KONAČNI TIP ĆE BIT ONAJ OD EXPRESSIONA
            Expression assignExpression = this->getAssignExpression();
            assignExpression->walk_down(classTable, expressionClass);
            if(!classTable->isSubtype(identificator->identificatorTypeDeclaration, assignExpression->type, (Class_*)expressionClass))
            {
                classTable->semant_error(expressionClass) << "Assign expression of identificator " << this->getAssignIdentificator() << " must be subtype of " << identificator->identificatorTypeDeclaration << endl;
                this->set_type(No_type);
            } 
            else this->set_type(assignExpression->type);
        }
    }
} 

void static_dispatch_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    //PROVJERA POSTOJI LI METODA U SPECIFICNOJ KLASI POSTAVLJENOM S @ OPERATOROM
    //TIP UZ @ ne smi bit SELF_TYPE
    //ovisno je li povratna vrijednost SELF_TYPE OSTAJE ISTA PROVJERA KAO U NORMALNOM DISPATCHU
    //1) ODREDI TIP EXPRESSIONA UZ KOJEG SE POZIVA METODA
    Expression dispatchExpression = this->getStaticDispatchExpression();
    dispatchExpression->walk_down(classTable, expressionClass);
    //PROVJERI POSTOJI LI TIP SPECIFICIRAN S @ U TABLICI KLASA
    class__class* dispatchClass = (class__class*)classTable->classesTable.probe(this->getStaticDispatchSpecifiedType());
    if(dispatchClass)
    {
        //bitno je provjeriti da je klasa za koju statički zovemo metodu nadtip od stvarne klase expressiona od dispatcha: T0 <= T
        if(classTable->isSubtype(dispatchClass->getClassName(),dispatchExpression->type, (Class_*)expressionClass))
        {
            //2) VIDI JEL POSTOJI METODA SA ZADANIM IMENON U TABLICKI METODA TRENUTNE KLASE
            //UKLJUCUJE I SVE NASLIJEDENE METODE TE KLASE
            method_class* classMethod = (method_class*)classTable->checkClassMethod(this->getStaticDispatchMethodName(),this->getStaticDispatchSpecifiedType());
            if(classMethod)
            {
                //PROVJERI JESU LI TIPOVI ARGUMENATA ISPRAVNI I JE LI PROSLIJEDEN TOCAN BROJ ARGUMENATA
                Expressions dispatchArguments = this->getStaticDispatchArguments();
                Formals methodFormals = classMethod->getMethodFormals();
                if(dispatchArguments->len() == methodFormals->len())
                {
                    //PROVJERA TIPOVA
                    Expression currentArgument;
                    formal_class* currentFormal;
                    for(int argumentIndex = dispatchArguments->first(); dispatchArguments->more(argumentIndex); argumentIndex = dispatchArguments->next(argumentIndex))
                    {
                        currentArgument = dispatchArguments->nth(argumentIndex);
                        currentArgument->walk_down(classTable, expressionClass);
                        currentFormal = (formal_class*)methodFormals->nth(argumentIndex);
                        if(!classTable->isSubtype(currentFormal->getTypeDeclaration(), currentArgument->type, (Class_*)expressionClass))
                        {
                            classTable->semant_error(expressionClass) << "Argument at index " << argumentIndex << " is not subtype of type " << currentFormal->getTypeDeclaration() << " specified in method definition" <<endl;
                            this->set_type(No_type); 
                        }
                    }
                    //VRIJEDNOST EXPRESSIONA METODE OVISNO O SELF_TYPE
                    if(classMethod->getMethodReturnType() != SELF_TYPE)
                    {
                        this->set_type(classMethod->getMethodReturnType());
                    }
                    else this->set_type(dispatchExpression->type);
                }
                else {
                    classTable->semant_error(expressionClass) << "Invalid number of arguments for method " << this->getStaticDispatchMethodName() <<endl;
                    this->set_type(No_type);
                }
            }
            else {
                classTable->semant_error(expressionClass) << "Method with name " << this->getStaticDispatchMethodName() << " is not defined in class "<< dispatchClass->getClassName() <<endl;
                this->set_type(No_type);
            }
        }
        else {
            classTable->semant_error(expressionClass) << "Static dispatch type specified with @ must be parent of type " << dispatchExpression->type <<endl;
            this->set_type(No_type);
        }
    }
    else {
        classTable->semant_error(expressionClass) << "Invalid dispatch type" <<endl;
        this->set_type(No_type);
    }
} 

void dispatch_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    //1) ODREDI TIP EXPRESSIONA UZ KOJEG SE POZIVA METODA
    Expression dispatchExpression = this->getMethodDispatchExpression();
    dispatchExpression->walk_down(classTable, expressionClass);
    Symbol dispatchExpressionType;
    //AKO DISPATCH EXPRESSION NIJE NAVEDEN ONDA JE ON IMPLICITNO self -> TRAZIMO METODE U TRENUTNOJ KLASI
    if(dispatchExpression->type == SELF_TYPE)//ključna riječ self ili izraz new SELF_TYPE
    {
        dispatchExpressionType = expressionClass->getClassName();
    }
    else dispatchExpressionType = dispatchExpression->type;
    class__class* dispatchClass = (class__class*)classTable->classesTable.probe(dispatchExpressionType);
    if(dispatchClass)
    {
        //2) VIDI JEL POSTOJI METODA SA ZADANIM IMENON U TABLICI METODA TRENUTNE KLASE
        method_class* classMethod = (method_class*)classTable->checkClassMethod(this->getMethodDispatchName(), dispatchExpressionType);
        if(classMethod)
        {
            //PROVJERI JESU LI TIPOVI ARGUMENATA ISPRAVNI I JE LI PROSLIJEDEN TOCAN BROJ ARGUMENATA
            Expressions dispatchArguments = this->getMethodDispatchArguments();
            Formals methodFormals = classMethod->getMethodFormals();
            if(dispatchArguments->len() == methodFormals->len())
            {
                //PROVJERA TIPOVA
                Expression currentArgument;
                formal_class* currentFormal;
                for(int argumentIndex = dispatchArguments->first(); dispatchArguments->more(argumentIndex); argumentIndex = dispatchArguments->next(argumentIndex))
                {
                    currentArgument = dispatchArguments->nth(argumentIndex);
                    currentArgument->walk_down(classTable, expressionClass);
                    currentFormal = (formal_class*)methodFormals->nth(argumentIndex);
                    if(!classTable->isSubtype(currentFormal->getTypeDeclaration(), currentArgument->type, (Class_*)expressionClass))
                    {
                        classTable->semant_error(expressionClass) << "Argument at index " << argumentIndex << " is not subtype of type " << currentFormal->getTypeDeclaration() << " specified in method definition" <<endl;
                        this->set_type(No_type); 
                    }
                }
                //VRIJEDNOST EXPRESSIONA METODE OVISNO O SELF_TYPE
                if(classMethod->getMethodReturnType() != SELF_TYPE)
                {
                    this->set_type(classMethod->getMethodReturnType());
                }
                else this->set_type(dispatchExpression->type);
            }
            else {
                classTable->semant_error(expressionClass) << "Invalid number of arguments for method " << this->getMethodDispatchName() <<endl;
                this->set_type(No_type);
            }
        }
        else {
            classTable->semant_error(expressionClass) << "Method with name " << this->getMethodDispatchName() << " is not defined in class "<< dispatchExpressionType <<endl;
            this->set_type(No_type);
        }
    }
    else {
        classTable->semant_error(expressionClass) << "Invalid dispatch type" <<endl;
        this->set_type(No_type);
    }
} 

void cond_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    //UVJETNI IZRAZ MORA BIT bool
    //POVRATNI TIP JE lub(e1,e2)
    Expression condExpression = this->getConditionExpression();
    Expression thenExpression = this->getThenExpression();
    Expression elseExpression = this->getElseExpression();
    condExpression->walk_down(classTable, expressionClass);
    thenExpression->walk_down(classTable,expressionClass);
    elseExpression->walk_down(classTable,expressionClass);
    if(condExpression->type == Bool)
    {
        this->set_type(classTable->leastUppperBound(thenExpression->type,elseExpression->type, (Class_*)expressionClass));
    }
    else {
        classTable->semant_error(expressionClass) << "Conditional expression must evaluate to Bool type" <<endl;
        this->set_type(No_type);
    }
} 

void loop_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    Expression condExpression = this->getLoopPredicate();
    Expression bodyExpression = this->getLoopBody();
    condExpression->walk_down(classTable,expressionClass);
    bodyExpression->walk_down(classTable,expressionClass);
    if(condExpression->type == Bool)
    {
        //tip petlje je Object
        this->set_type(Object);
    }
    else {
        classTable->semant_error(expressionClass) << "Conditional expression must evaluate to Bool type" <<endl;
        this->set_type(No_type);
    }
} 

void typcase_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    Expression mainExpression = this->getMainExpression();
    mainExpression->walk_down(classTable, expressionClass);
    Cases cases = this->getCaseBranches();
    Symbol branchTypes[cases->len()];
    branch_class* currentBranch;
    for(int branchIndex = cases->first();cases->more(branchIndex);branchIndex = cases->next(branchIndex))
    {
        currentBranch = (branch_class*)cases->nth(branchIndex);
        //NE SMI BIT VISE BRANCHEVA S ISTIM TIPOM -> PRETRAZI MOGUCI DUPLIKAT
        branch_class* currentDuplicateBranch;
        for(int branchDuplicateIndex = cases->first();cases->more(branchDuplicateIndex);branchDuplicateIndex = cases->next(branchDuplicateIndex))
        {
            if(branchDuplicateIndex != branchIndex)
            {
                currentDuplicateBranch = (branch_class*)cases->nth(branchDuplicateIndex);
                if(currentDuplicateBranch->getBranchIdentificatorType() == currentBranch->getBranchIdentificatorType())
                {
                    classTable->semant_error(expressionClass) << "Duplicate branch " << currentBranch->getBranchIdentificatorType() << " in case statement" << endl;
                    this->set_type(No_type);
                    return; 
                }
            }
        }
        //PROSIRI DOSEG ZA SVAKU GRANU I ODREDI TIP EXPRESSIONA I NAKON TOGA IZADI IZ DOSEGA
        expressionClass->identificatorsTable.enterscope();
        expressionClass->identificatorsTable.addid(currentBranch->getBranchIdentificatorName(), (tree_node*)currentBranch);
        currentBranch->identificatorTypeDeclaration = currentBranch->getBranchIdentificatorType();
        Expression currentBranchExpression = currentBranch->getBranchExpression();
        currentBranchExpression->walk_down(classTable,expressionClass);
        branchTypes[branchIndex] = currentBranchExpression->type;
        expressionClass->identificatorsTable.exitscope();
    }
    //PRONAC LUB OD VISE CVOROVA KORISTECI FORMULU ZA 2 CVORA -> https://stackoverflow.com/questions/11449534/least-common-ancestor-of-multiple-nodes-in-dag
    //NADI ZA PRVA 2(OD KRAJA) I ONDA NJIHOV REZULOTAT SA TRECIM itd. -> n-1 puta
    Symbol lub=branchTypes[(cases->len()-1)];
    for(int i=(cases->len()-2);i>=0;i--)
    {
        lub=classTable->leastUppperBound(lub,branchTypes[i],(Class_*)expressionClass);
    }
    this->set_type(lub);
} 

void block_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    Expressions blockExpressions = this->getBlockExpressions();
    //prodi kroz sve expressione
    Expression currentExpression;
    for(int expressionIndex = blockExpressions->first(); blockExpressions->more(expressionIndex); expressionIndex = blockExpressions->next(expressionIndex))
    {
        currentExpression = blockExpressions->nth(expressionIndex);
        currentExpression->walk_down(classTable, expressionClass);
    }
    // The static type of a block is the static type of the last expression
    Expression lastExpression = blockExpressions->nth(blockExpressions->len()-1);
    this->set_type(lastExpression->type);
    
} 

void let_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    //it is an error to assign to self or to bind self in a let, a case, ---or as a formal parameter---- -> NE SMI let IDENTIFIKATOR BIT self
    if(this->getLetIdentificator() != self)
    {
        Expression initExpression = this->getLetIdentificatorInitExpression();
        initExpression->walk_down(classTable,expressionClass);
        //TIP init expressiona mora bit podtip od specificiranog expressiona
        if(classTable->isSubtype(this->getLetIdentificatorType(),initExpression->type,(Class_*)expressionClass))
        {
            //PROŠIRI DOSEG SA IDENTIFIKATOROM OD let
            expressionClass->identificatorsTable.enterscope();
            expressionClass->identificatorsTable.addid(this->getLetIdentificator(),(tree_node*)this);
            this->identificatorTypeDeclaration = this->getLetIdentificatorType();
            Expression bodyExpression = this->getLetBodyExpression();
            bodyExpression->walk_down(classTable,expressionClass);
            expressionClass->identificatorsTable.exitscope();
            //TIP let izraza je tip body expressiona
            this->set_type(bodyExpression->type);
        }
        else {
            classTable->semant_error(expressionClass) << "Initialization expression must be subtype of " << this->getLetIdentificatorType() << " Computed type is " << initExpression->type <<endl;
            this->set_type(No_type);
        }
    }
    else {
        classTable->semant_error(expressionClass) << "'self' cannot be bound in a 'let' expression." << endl;
        this->set_type(No_type);
    }
}

//SAMO ZA SLUCAJEVE KAD SU OBA OPERANDA Int DOZOVLJENE NUMERICKE OPERACIJE(IZNIMKA JE OPERATOR =)

void plus_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    this->getFirstOperandExpression()->walk_down(classTable, expressionClass);
    this->getSecondOperandExpression()->walk_down(classTable, expressionClass);
    if(this->getFirstOperandExpression()->type != Int)
    {
        classTable->semant_error(expressionClass) << "Left operand in + operation must be integer" << endl;
        //postavi No_type i nastavi analizu
        this->set_type(No_type);
    }
    else if(this->getSecondOperandExpression()->type != Int)
    {
        classTable->semant_error(expressionClass) << "Right operand in + operation must be integer" << endl;
        //postavi No_type i nastavi analizu
        this->set_type(No_type);
    }
    else this->set_type(Int);
} 

void sub_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    this->getFirstOperandExpression()->walk_down(classTable, expressionClass);
    this->getSecondOperandExpression()->walk_down(classTable, expressionClass);
    if(this->getFirstOperandExpression()->type != Int)
    {
        classTable->semant_error(expressionClass) << "Left operand in - operation must be integer" << endl;
        //postavi No_type i nastavi analizu
        this->set_type(No_type);
    }
    else if(this->getSecondOperandExpression()->type != Int)
    {
        classTable->semant_error(expressionClass) << "Right operand in - operation must be integer" << endl;
        //postavi No_type i nastavi analizu
        this->set_type(No_type);
    }
    else this->set_type(Int);
} 

void mul_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    this->getFirstOperandExpression()->walk_down(classTable, expressionClass);
    this->getSecondOperandExpression()->walk_down(classTable, expressionClass);
    if(this->getFirstOperandExpression()->type != Int)
    {
        classTable->semant_error(expressionClass) << "Left operand in * operation must be integer" << endl;
        //postavi No_type i nastavi analizu
        this->set_type(No_type);
    }
    else if(this->getSecondOperandExpression()->type != Int)
    {
        classTable->semant_error(expressionClass) << "Right operand in * operation must be integer" << endl;
        //postavi No_type i nastavi analizu
        this->set_type(No_type);
    }
    else this->set_type(Int);
} 

void divide_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    this->getFirstOperandExpression()->walk_down(classTable, expressionClass);
    this->getSecondOperandExpression()->walk_down(classTable, expressionClass);
    if(this->getFirstOperandExpression()->type != Int)
    {
        classTable->semant_error(expressionClass) << "Left operand in / operation must be integer" << endl;
        //postavi No_type i nastavi analizu
        this->set_type(No_type);
    }
    else if(this->getSecondOperandExpression()->type != Int)
    {
        classTable->semant_error(expressionClass) << "Right operand in / operation must be integer" << endl;
        //postavi No_type i nastavi analizu
        this->set_type(No_type);
    }
    else this->set_type(Int);
} 

void neg_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    //mora biti Int tipa izraz koji se negira
    //~1 = -1
    this->getNegExpression()->walk_down(classTable, expressionClass);
    if(this->getNegExpression()->type != Int)
    {
        classTable->semant_error(expressionClass) << "~ operation can be used only on integer types" << endl;
        this->set_type(No_type);
    }
    else {
        this->set_type(Int);
    }
} 

void lt_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    this->getFirstOperandExpression()->walk_down(classTable, expressionClass);
    this->getSecondOperandExpression()->walk_down(classTable, expressionClass);
    if(this->getFirstOperandExpression()->type != Int)
    {
        classTable->semant_error(expressionClass) << "Left operand in < operation must be integer" << endl;
        this->set_type(No_type);
    }
    else if(this->getSecondOperandExpression()->type != Int)
    {
        classTable->semant_error(expressionClass) << "Right operand in < operation must be integer" << endl;
        this->set_type(No_type);
    }
    else this->set_type(Bool);
} 

void eq_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    // The comparison = is a special case. If either <expr1> or <expr2> has static type Int, Bool, or String, then the other must have the same static type. Any other types, including SELF TYPE, may be freely compared.
    this->getFirstOperandExpression()->walk_down(classTable, expressionClass);
    this->getSecondOperandExpression()->walk_down(classTable, expressionClass);
    if((this->getFirstOperandExpression()->type == Int && this->getSecondOperandExpression()->type != Int) || (this->getFirstOperandExpression()->type != Int && this->getSecondOperandExpression()->type == Int))
    {
        classTable->semant_error(expressionClass) << "Both operands of = operator must be of type Int" << endl;
        this->set_type(No_type);
    }
    else if((this->getFirstOperandExpression()->type == Str && this->getSecondOperandExpression()->type != Str) || (this->getFirstOperandExpression()->type != Str && this->getSecondOperandExpression()->type == Str))
    {
        classTable->semant_error(expressionClass) << "Both operands of = operator must be of type String" << endl;
        this->set_type(No_type);
    }
    else if((this->getFirstOperandExpression()->type == Bool && this->getSecondOperandExpression()->type != Bool) || (this->getFirstOperandExpression()->type != Bool && this->getSecondOperandExpression()->type == Bool))
    {
        classTable->semant_error(expressionClass) << "Both operands of = operator must be of type Bool" << endl;
        this->set_type(No_type);
    }
    else this->set_type(Bool);
} 

void leq_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    this->getFirstOperandExpression()->walk_down(classTable, expressionClass);
    this->getSecondOperandExpression()->walk_down(classTable, expressionClass);
    if(this->getFirstOperandExpression()->type != Int)
    {
        classTable->semant_error(expressionClass) << "Left operand in <= operation must be integer" << endl;
        this->set_type(No_type);
    }
    else if(this->getSecondOperandExpression()->type != Int)
    {
        classTable->semant_error(expressionClass) << "Right operand in <= operation must be integer" << endl;
        this->set_type(No_type);
    }
    else this->set_type(Bool);
} 

void comp_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    //komplement od bool -> not keyword operator samo nad bool operandima
    this->getNotExpression()->walk_down(classTable, expressionClass);
    if(this->getNotExpression()->type != Bool)
    {
        classTable->semant_error(expressionClass) << "Not operator can only be used on boolena operand" << endl;
        this->set_type(No_type);
    }
    else this->set_type(Bool);
} 

void int_const_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    this->set_type(Int);
} 

void bool_const_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    this->set_type(Bool);
} 

void string_const_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    this->set_type(Str);
} 

void new__class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    //AKO new SELF_TYPE onda je izraz SELF_TYPE tipa(nema ga u tablici klasa pa ga odvajamo)
    if(this->getNewTypename() == SELF_TYPE)
    {
        this->set_type(this->getNewTypename());
    }
    else {
        //PROVJERI JE LI SE new poziva ne nedefiniranom tipu
        if(classTable->classesTable.probe(this->getNewTypename()))
        {
            this->set_type(this->getNewTypename());
        }
        else {
            classTable->semant_error(expressionClass) << "'new' used with undefined class " << this->getNewTypename() << endl;
            this->set_type(No_type);
        }

    }
} 

void isvoid_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    Expression voidExpression = this->getVoidExpression();
    voidExpression->walk_down(classTable, expressionClass);
    this->set_type(Bool);
} 

void no_expr_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    //ako nema expressiona onda postavi No_type za tip expressiona
    this->set_type(No_type);
} 

void object_class::walk_down(ClassTable* classTable, class__class* expressionClass)
{
    //identifikator treba biti prethodno deklariran ako se zeli koristit
    //self identifikator je SELF_TYPE tipa
    if(this->getObjectIDName() == self)
    {
        this->set_type(SELF_TYPE);
    }
    else {
        tree_node* identificator = classTable->checkClassIdentifier(this->getObjectIDName(),expressionClass->getClassName());
        if(identificator)
        {
            this->set_type(identificator->identificatorTypeDeclaration);
        }
        else {
            classTable->semant_error(expressionClass) << "Undeclared identifier " << this->getObjectIDName() << endl;
            this->set_type(No_type);
        }
    }
} 

bool ClassTable::isSubtype(Symbol parentClassName, Symbol childClassName, Class_* currentClass)
{
    //childType(podtip) se u stablu nasljedivanja nalazi ispod parentType-a
    //ako je parent=Object onda je sigurno childType podtip
    //ako je child = parent onda to vrijedi takoder
    //No type je podtip od svih tipova
    if(parentClassName == Object || childClassName == parentClassName || childClassName == No_type)
    {
        return true;
    }//'NORMALNI' SLUCAJEVI KAD NIJEDAN OPERAND NIJE SELF_TYPE
    if(parentClassName != SELF_TYPE && childClassName != SELF_TYPE)
    {
        //inace provjeravaj od childa prema gore(sve roditelje) sve dok ne nademo parentTip
        class__class* currentChildClass;
        while(childClassName!=No_class)
        {
            currentChildClass = (class__class*)this->classesTable.probe(childClassName);
            if(currentChildClass->getParentName() == parentClassName)
            {
                return true;
            }
            childClassName = currentChildClass->getParentName();//penji se prema gore
        }
        //dosli do kraja -> nije pronaden zadani parent u stablu nasljeđivanja childa -> false
        return false;
    }
    else {
        //SELF_TYPE SLUCAJEVI
        if(parentClassName == SELF_TYPE && childClassName == SELF_TYPE)
        {
            return true;
        }
        else if(childClassName == SELF_TYPE)
        {
            //SELF_TYPEC <= T ako C <= T
            return this->isSubtype(parentClassName,((class__class*)currentClass)->getClassName(),currentClass);
        }
        else if(parentClassName == SELF_TYPE)
        {
            //T <= SELF_TYPEC je općenito laž
            return false;
        }
        else return false;
    }
}

Symbol ClassTable::leastUppperBound(Symbol firstClass, Symbol secondClass, Class_* currentClass)
{
    if(firstClass != SELF_TYPE && secondClass != SELF_TYPE)
    {
        //trazi prvog zajednickog pretka u stablu nasljedivanja klasa
        //rekurzivno se penjemo po stablu sve dok ne dodemo do vrha
        //ako smo dosli do vrha onda im je lub = Object tip
        //ako je neki od tipova klasa No_type onda se drugi tip moze proglasit zajednickim pretkom(jer je no_type podtip od svih)
        //ako su tipovi u parent child odnosu onda im je najblizi zajednicki predak upravo parent tip
        //PENJEMO SE PO PRVOM TIPU I GLEDAMO JESMO LI DOSLI DO TRENUTKA OSTVARENJA parent-child odnosa
        if(this->isSubtype(firstClass,secondClass,currentClass) || secondClass == No_type){
            return firstClass;
        }
        //UKOLIKO SE DOGODI DA JE DRUGI TIP PO KOJEM SE NE PENJEMO PARENT OF PRVOG TIPA -> KRAJ
        else if(this->isSubtype(secondClass,firstClass,currentClass) || firstClass == No_type ){
            return secondClass;
        }
        else {
            //inace se penji prema gore u stablu SAMO PO PRVOM TIPU/KLASI(ili drugog nije bitno)
            //penji se sve dok ne dobijes da imas parent-child odnos izmedu 'popnutog' tipa i drugog tipa -> TADA SMO DOSLI DO ZAJEDNICKOG PRETKA KOJI IM JE OBOJICI NAJBLIZI ZAJEDNICKI RODITELJ
            class__class* currentChildClass = (class__class*)this->classesTable.probe(firstClass);
            return this->leastUppperBound(currentChildClass->getParentName(),secondClass, currentClass); 
        }
    }
    else {
        //OBRADI SELF_TYPE SLUCAJEVE
        if(firstClass == SELF_TYPE && secondClass == SELF_TYPE)
        {
            return SELF_TYPE;
        }//lub(SELF_TYPE, T) = lub(C, T) + simetricnost
        else if(firstClass == SELF_TYPE)
        {
            return this->leastUppperBound(((class__class*)currentClass)->getClassName(),secondClass, currentClass);
        }//lub(T, C)
        else return this->leastUppperBound(((class__class*)currentClass)->getClassName(),firstClass, currentClass);
    }
}

tree_node* ClassTable::checkClassIdentifier(Symbol identificatorName, Symbol currentClassName)
{
    //PROVJERA POSTOJI LI IDENTIFIKATOR U TRENUTNOJ KLASI I SVE DO VRHA LANCA NASLJEDIVANJA
    //No_class oznacava kraj lanca
    if(currentClassName == No_class)
    {
        return NULL;
    }
    else {
        class__class* currentClass = (class__class*)this->classesTable.probe(currentClassName);
        tree_node* identificator = currentClass->identificatorsTable.probe(identificatorName);
        if(identificator)
        {
            return identificator;
        }
        else {
            //provjeri u svim dosezima trenutne klase
            identificator = currentClass->identificatorsTable.lookup(identificatorName);
            if(identificator)
            {
                return identificator;
            }//PROVJERAVAJ DALJE U LANCU
            else return this->checkClassIdentifier(identificatorName, currentClass->getParentName());
        }
    }
}

tree_node* ClassTable::checkClassMethod(Symbol methodName, Symbol currentClassName)
{
    //PROVJERA POSTOJI LI METODA U TRENUTNOJ KLASI I SVE DO VRHA LANCA NASLJEDIVANJA
    //No_class oznacava kraj lanca
    if(currentClassName == No_class)
    {
        return NULL;
    }
    else {
        class__class* currentClass = (class__class*)this->classesTable.probe(currentClassName);
        tree_node* method = currentClass->methodsTable.probe(methodName);
        if(method)
        {
            return method;
        }
        else return this->checkClassMethod(methodName, currentClass->getParentName());
    }
}

bool ClassTable::checkAttributeOverride(Symbol attributeName, Symbol currentClassName)
{
    if(currentClassName == No_class)
    {
        return false;
    }
    else {
        class__class* currentClass = (class__class*)this->classesTable.probe(currentClassName);
        if(currentClass->identificatorsTable.probe(attributeName))
        {
            return true;
        }
        else return this->checkAttributeOverride(attributeName, currentClass->getParentName());
    }
}

bool ClassTable::checkMethodOverride(Feature targetMethodFeature, Symbol currentClassName, Class_* originClass)
{
    //The rule is simple: If a class C inherits a method f from an ancestor class P, then C may override the inherited definition of f provided the number of arguments, the types of the formal parameters, and the return type are exactly the same in both definitions
    if(currentClassName == No_class)
    {
        return false;
    }
    else {
        class__class* currentClass = (class__class*)this->classesTable.probe(currentClassName);
        //PRVO PROVJERI POSTOJI LI METODA S ISTIM IMENOM
        method_class* targetMethod = (method_class*)targetMethodFeature;
        method_class* currentMethod = (method_class*)currentClass->methodsTable.probe(targetMethod->getMethodName());
        if(currentMethod)
        {
            //PROVJERI JESU LI IM SVI PARAMETRI KOJI DEFINIRAJU METODU ISTI
            if(currentMethod->getMethodReturnType() != targetMethod->getMethodReturnType())
            {
                this->semant_error((class__class*)originClass) << "In redefined method " << targetMethod->getMethodName() << " return type " << targetMethod->getMethodReturnType() << " is different from original return type " << currentMethod->getMethodReturnType() << endl;
                return true;
            }
            if(currentMethod->getMethodFormals()->len() != targetMethod->getMethodFormals()->len())
            {
                this->semant_error((class__class*)originClass) << "In redefined method " << targetMethod->getMethodName() << " number of arguments is different than in original method definition" << endl;
                return true; 
            }
            Formals targetMethodFormals = targetMethod->getMethodFormals();
            Formals currentMethodFormals = currentMethod->getMethodFormals();
            formal_class* targetMethodFormal;
            formal_class* currentMethodFormal;
            for(int formalIndex = currentMethodFormals->first(); currentMethodFormals->more(formalIndex); formalIndex = currentMethodFormals->next(formalIndex))
            {
                currentMethodFormal = (formal_class*)currentMethodFormals->nth(formalIndex);
                targetMethodFormal = (formal_class*)targetMethodFormals->nth(formalIndex);
                if(currentMethodFormal->getTypeDeclaration() != targetMethodFormal->getTypeDeclaration())
                {
                    this->semant_error((class__class*)originClass) << "In redefined method " << targetMethod->getMethodName() << " parameter type " << targetMethodFormal->getTypeDeclaration() << " is different from original type " << currentMethodFormal->getTypeDeclaration() << endl;
                    return true;
                }
            }
            
        }
        return this->checkMethodOverride(targetMethodFeature, currentClass->getParentName(), originClass);
    }
}

//------------------------------------------------------------------------------
//PROVJERA CIKLICNOSTI GRAFA
//KOPIRANO S https://www.geeksforgeeks.org/detect-cycle-in-a-graph/
//------------------------------------------------------------------------------
Graph::Graph(int V)
{
    this->V = V;
    adj = new std::list<int>[V];
}
  
void Graph::addEdge(int v, int w)
{
    adj[v].push_back(w); // Add w to v’s list.
}
  
// This function is a variation of DFSUtil() in 
// https://www.geeksforgeeks.org/archives/18212
bool Graph::isCyclicUtil(int v, bool visited[], bool *recStack)
{
    if(visited[v] == false)
    {
        // Mark the current node as visited and part of recursion stack
        visited[v] = true;
        recStack[v] = true;
  
        // Recur for all the vertices adjacent to this vertex
        std::list<int>::iterator i;
        for(i = adj[v].begin(); i != adj[v].end(); ++i)
        {
            if ( !visited[*i] && isCyclicUtil(*i, visited, recStack) )
                return true;
            else if (recStack[*i])
                return true;
        }
  
    }
    recStack[v] = false;  // remove the vertex from recursion stack
    return false;
}
  
// Returns true if the graph contains a cycle, else false.
// This function is a variation of DFS() in 
// https://www.geeksforgeeks.org/archives/18212
bool Graph::isCyclic()
{
    // Mark all the vertices as not visited and not part of recursion
    // stack
    bool *visited = new bool[V];
    bool *recStack = new bool[V];
    for(int i = 0; i < V; i++)
    {
        visited[i] = false;
        recStack[i] = false;
    }
  
    // Call the recursive helper function to detect cycle in different
    // DFS trees
    for(int i = 0; i < V; i++)
        if ( !visited[i] && isCyclicUtil(i, visited, recStack))
            return true;
  
    return false;
}
//------------------------------------------------------------------------------

void program_class::semant()
{
    initialize_constants();
    //SVE SE MIJENJA PREKO POKAZIVACA TAKO DA PROMJENE OSTANU SPREMLJENE U GLAVNOM AST STABLU
    /* ClassTable constructor may do some semantic analysis */
    //1. OBLIZAKA AST-A -> NAPUNI OKOLINU KLASA + OKOLINU ATRIBUTA I METODA ZA SVAKU KLASU
    //AKO SE DOGODI GRESKA U PRVOM PROLAZU NE IDEMO U DRUGI PROLAZ
    ClassTable *classtable = new ClassTable(classes);
    /* some semantic analysis code may go here */
    if (classtable->errors()) {
        cerr << "Compilation halted due to static semantic errors." << endl;
        exit(1);
    }
    else {
        //2. OBILAZAK -> proći kroz sve klase i za njihove članove napraviti dvije stvari:
        this->walk_down(classtable);
        if (classtable->errors()) {
        cerr << "Compilation halted due to static semantic errors." << endl;
        exit(1);
        }
    }
}


