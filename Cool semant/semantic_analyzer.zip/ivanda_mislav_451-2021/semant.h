#ifndef SEMANT_H_
#define SEMANT_H_

class ClassTable;
typedef ClassTable *ClassTableP;

#include <assert.h>
#include <iostream>  
#include "cool-tree.h"
#include "stringtab.h"
#include "symtab.h"//za classesTable
#include <iterator>
#include <list>

#define TRUE 1
#define FALSE 0

// This is a structure that may be used to contain the semantic
// information such as the inheritance graph.  You may use it or not as
// you like: it is only here to provide a container for the supplied
// methods.
//PROVJERA CIKLICNOSTI GRAFA
//KOPIRANO S https://www.geeksforgeeks.org/detect-cycle-in-a-graph/
class Graph
{
  private:
    int V;    // No. of vertices
    std::list<int> *adj;    // Pointer to an array containing adjacency lists
    bool isCyclicUtil(int v, bool visited[], bool *rs);  // used by isCyclic()
  public:
    Graph(int V);   // Constructor
    void addEdge(int v, int w);   // to add an edge to graph
    bool isCyclic();    // returns true if there is a cycle in this graph
};

class ClassTable {
private:
  int semant_errors;
  void install_basic_classes(Graph classesGraph, int* vertexNumbers);
  ostream& error_stream;
public:
  ClassTable(Classes);
  int errors() { return semant_errors; }
  ostream& semant_error();
  ostream& semant_error(Class_ c);
  ostream& semant_error(Symbol filename, tree_node *t);
  //okolina svih klasa
  SymbolTable<Symbol,tree_node> classesTable;//POHRANJUJEMO tree_node TIP jer ga svi ostali cvorovi nasljeduju/implementiraju
  SymbolTable<Symbol,int> classNameToNumberMapping;//za svako ime klase će spremit njegov indeks u classes listi koji ce definirat indeks cvora u grafu
  //Utility metode
  bool isSubtype(Symbol parentType, Symbol childType, Class_* currentClass);
  Symbol leastUppperBound(Symbol type1, Symbol type2, Class_* currentClass);
  tree_node* checkClassIdentifier(Symbol identificatorName, Symbol currentClassName);
  tree_node* checkClassMethod(Symbol methodName, Symbol currentClassName);
  bool checkAttributeOverride(Symbol attributeName, Symbol currentClassName);
  bool checkMethodOverride(Feature targetMethodFeature, Symbol currentClassName, Class_* originClass);
};
#endif

